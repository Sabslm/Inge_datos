import pandas as pd
import psycopg2 as psy2
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import dash_table as dt

def DiferenciaAreasgrupo():
    return """SELECT SUM(area_sembrada - area_cosechada) AS diferencia, grupo.nombre AS grupo, produccion.anio_anio_periodo AS anio
              FROM produccion
              LEFT JOIN cultivo ON (produccion.codigo_cultivo = cultivo.codigo)
              LEFT JOIN subgrupo ON (cultivo.id_subgrupo = subgrupo.id)
              LEFT JOIN grupo ON (subgrupo.id_grupo = grupo.id)
              WHERE anio_anio_periodo = '2020' OR anio_anio_periodo = '2019'
              GROUP BY grupo.nombre, produccion.anio_anio_periodo
              ORDER BY diferencia DESC;"""

# Database connection details
dbname = "proyecto_final"
user = "postgres"
password = "12345"
host = "localhost"

# Connect to the database
conn = psy2.connect(dbname=dbname, user=user, password=password, host=host)
sql_query = DiferenciaAreasgrupo()
df = pd.read_sql(sql_query, conn)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1('Diferencia de Área Sembrada y Cosechada por Grupo'),
    dcc.Graph(
        id='graph_diferencia_areas_grupo',
        figure=px.bar(df, x='anio', y='diferencia', color='grupo', title='Diferencia de Área Sembrada y Cosechada por Grupo')
    ),
    dt.DataTable(
        id='table',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict('records')
    )
])

# Run the app
if __name__ == '__main__':
    app.run_server(port=8056)
