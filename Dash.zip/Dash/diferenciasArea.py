import pandas as pd
import psycopg2 as psy2
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import dash_table as dt

def DiferenciaAreas():
    return """SELECT SUM(area_sembrada - area_cosechada) AS diferencia, cultivo.nombre AS cultivo
              FROM produccion
              INNER JOIN cultivo ON (cultivo.codigo = produccion.codigo_cultivo)
              GROUP BY cultivo.nombre
              ORDER BY cultivo.nombre;"""

# Database connection details
dbname = "proyecto_final"
user = "postgres"
password = "12345"
host = "localhost"

# Connect to the database
conn = psy2.connect(dbname=dbname, user=user, password=password, host=host)
sql_query = DiferenciaAreas()
df = pd.read_sql(sql_query, conn)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1('Diferencia de Área Sembrada y Cosechada por Cultivo'),
    dcc.Graph(
        id='graph_diferencia_areas',
        figure=px.bar(df, x='cultivo', y='diferencia', title='Diferencia de Área Sembrada y Cosechada por Cultivo')
    ),
    dt.DataTable(
        id='table',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict('records')
    )
])

# Run the app
if __name__ == '__main__':
    app.run_server(port=8055)
