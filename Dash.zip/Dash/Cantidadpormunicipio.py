import pandas as pd
import psycopg2 as psy2
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import dash_table as dt

def CantidadporMunicipio():
    return """SELECT departamento.nombre, AVG(produccion.cantidad)::NUMERIC(10,2)
              FROM produccion
              INNER JOIN municipio ON (id_municipio = municipio.id)
              INNER JOIN departamento ON (departamento.id = id_departamento)
              GROUP BY 1
              ORDER BY 1;"""

dbname = "proyecto_final"
user = "postgres"
password = "12345"
host = "localhost"

conn = psy2.connect(dbname=dbname, user=user, password=password, host=host)
sql_query = CantidadporMunicipio()
df = pd.read_sql(sql_query, conn)

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1('Cantidad por Municipio'),
    dcc.Graph(
        id='graph_cantidad_municipio',
        figure=px.bar(df, x='nombre', y='avg', title='Cantidad Promedio por Municipio')
    ),
    dt.DataTable(
        id='table',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict('records')
    )
])

if __name__ == '__main__':
    app.run_server(port=8051)
