import pandas as pd
import psycopg2 as psy2
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import dash_table as dt

def Rendimiento():
    return """SELECT (cantidad::float / area_cosechada) AS rendimiento, departamento.nombre AS departamento, cultivo.nombre AS cultivo
              FROM produccion
              LEFT JOIN municipio ON (produccion.id_municipio = municipio.id)
              LEFT JOIN departamento ON (municipio.id_departamento = departamento.id)
              LEFT JOIN cultivo ON (produccion.codigo_cultivo = cultivo.codigo)
              WHERE area_cosechada > 0 AND periodo_anio_periodo = '2019A';"""

# Database connection details
dbname = "proyecto_final"
user = "postgres"
password = "12345"
host = "localhost"

# Connect to the database
conn = psy2.connect(dbname=dbname, user=user, password=password, host=host)
sql_query = Rendimiento()
df = pd.read_sql(sql_query, conn)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1('Rendimiento por Departamento y Cultivo'),
    dcc.Graph(
        id='graph_rendimiento',
        figure=px.scatter(df, x='departamento', y='rendimiento', color='cultivo', title='Rendimiento por Departamento y Cultivo')
    ),
    dt.DataTable(
        id='table',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict('records')
    )
])

# Run the app
if __name__ == '__main__':
    app.run_server(port=8052)

