import pandas as pd
import psycopg2 as psy2
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import dash_table as dt

def Areasembradapermanentes():
    return """SELECT periodo_anio_periodo AS periodo, cultivo.nombre AS nombre, SUM(area_sembrada) AS area
              FROM produccion
              INNER JOIN cultivo ON (codigo_cultivo = cultivo.codigo)
              WHERE (periodo_anio_periodo = '2019A' OR periodo_anio_periodo = '2019B' 
              OR periodo_anio_periodo = '2020A' OR periodo_anio_periodo = '2020B')
              AND cultivo.id_ciclo_cultivo = 2
              GROUP BY periodo_anio_periodo, cultivo.nombre
              ORDER BY cultivo.nombre ASC;"""

dbname = "proyecto_final"
user = "postgres"
password = "12345"
host = "localhost"

conn = psy2.connect(dbname=dbname, user=user, password=password, host=host)
sql_query = Areasembradapermanentes()
df = pd.read_sql(sql_query, conn)

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1('Área Sembrada - Cultivos Permanentes'),
    dcc.Graph(
        id='graph_area_permanentes',
        figure=px.line(df, x='periodo', y='area', color='nombre', title='Área Sembrada de Cultivos Permanentes')
    ),
    dt.DataTable(
        id='table',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict('records')
    )
])

if __name__ == '__main__':
    app.run_server(port=8054)
